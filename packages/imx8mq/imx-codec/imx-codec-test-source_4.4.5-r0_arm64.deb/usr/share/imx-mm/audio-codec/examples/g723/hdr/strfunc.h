
 /************************************************************************
  * Copyright 2005-2010 by Freescale Semiconductor, Inc.
  * All modifications are confidential and proprietary information
  * of Freescale Semiconductor, Inc. ALL RIGHTS RESERVED.
  ************************************************************************/

#ifndef STRFUNC_H
#define STRFUNC_H
#define CYCLE_MEASUREMENT
#ifdef CYCLE_MEASUREMENT
extern int mystrcmp(const char*, const char*);
#endif

#endif
